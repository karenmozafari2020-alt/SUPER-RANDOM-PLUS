SUPER-RANDOM-PLUS — بسته ۱۵۰۰ تکسچر آیتم
این ZIP شامل ۱۵۰۰ تصویر PNG مجزا (۱۶×۱۶)، مدل آیتم، نام انگلیسی و فهرست CSV است.
این بسته فقط منابع (assets) را آماده می‌کند؛ هنوز ثبت آیتم‌ها در Java، تب Creative و سیستم جایزه تصادفی به مخزن اصلی اعمال نشده است.

ساختار:
- models/item: مدل ۱۵۰۰ آیتم
- textures/item: تکسچر ۱۵۰۰ آیتم
- lang/en_us.json: نام‌ها
- items.csv: فهرست و دسته‌بندی

برای ادغام: پوشه assets/superrandomplus را با حفظ فایل‌های موجود به src/main/resources/assets/ پروژه اضافه کنید.
توجه: این ZIP هنوز commit یا build در GitHub نشده است.
