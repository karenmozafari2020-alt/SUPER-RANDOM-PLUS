# SUPER-RANDOM-PLUS assets/recipes patch (Forge 1.20.1)
Adds item models, original 16x16 pixel textures, language names, and crafting recipes for the 190 generated IDs:
40 swords, 30 pickaxes, 25 axes, 20 shovels, 15 hoes, 20 special items, and 40 materials.
Every recipe uses Karen Crystal. Materials are crafted from Karen Crystal plus vanilla ingredients; tools/special items use Karen Crystal and Karen Materials.

IMPORTANT:
- Resource/recipe patch only; unique Java abilities are not implemented.
- No Java registry source is included.
- Copy `src/main/resources/assets` and `src/main/resources/data` into the project's `src/main/resources`.
- Verify Java registry IDs match the names here and confirm `superrandomplus:karen_crystal` exists before rebuilding.
